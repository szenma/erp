def get_data():
	return {
		"fieldname": "payment_order",
		"transactions": [{"products": ["Payment Entry", "Journal Entry"]}],
	}
