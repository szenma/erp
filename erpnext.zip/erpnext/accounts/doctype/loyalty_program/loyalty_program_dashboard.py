def get_data():
	return {
		"fieldname": "loyalty_program",
		"transactions": [{"products": ["Sales Invoice", "Customer"]}],
	}
