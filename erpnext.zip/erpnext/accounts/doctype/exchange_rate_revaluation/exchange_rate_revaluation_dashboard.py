def get_data():
	return {"fieldname": "reference_name", "transactions": [{"products": ["Journal Entry"]}]}
